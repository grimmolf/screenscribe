#!/bin/bash
# scribe installation script for linux-arm64
mkdir -p ~/.local/bin
cp scribe whisper_wrapper.py extract_frames.sh youtube_helper.py ~/.local/bin/
chmod +x ~/.local/bin/whisper_wrapper.py ~/.local/bin/extract_frames.sh ~/.local/bin/youtube_helper.py
mkdir -p ~/.config/fabric/patterns
cp -r patterns/* ~/.config/fabric/patterns/
echo 'Installation complete! Make sure ~/.local/bin is in your PATH'
echo 'For YouTube support, install yt-dlp: pip install yt-dlp'
